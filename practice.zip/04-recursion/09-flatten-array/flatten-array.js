function flattenArray(arr) {
    let narr = []
    for(let i=0;i<arr.length;i++){
        if(Array.isArray(arr[i])){
            narr = narr.concat(flattenArray(arr[i]))
        }else {
            narr.push(arr[i])
        }
    }
    return narr
}

module.exports = flattenArray;
