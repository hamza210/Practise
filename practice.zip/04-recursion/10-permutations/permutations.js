function permutations(str) {
    let arr = []
    if(str.length ===0){
        arr.push('')
        return arr
    }

    for(let i =0;i<str.length;i++){
        const firstletter = str[i]
        const restofstring  = str.slice(0,i) + str.slice(i+1)
        const permutation = permutations(restofstring)
        for(let j =0;j<permutation.length;j++){
            let nstr = firstletter+permutation[j]
            arr.push(nstr)
        }
    }

    return arr
}

module.exports = permutations;
