const factorial = require('./factorial');

const result = factorial(4);

console.log(result);
