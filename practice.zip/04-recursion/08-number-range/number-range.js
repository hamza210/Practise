function numberRange(strt,end) {
    if(strt == end){
        return [strt]
    }

    let arr = numberRange(strt,end-1)
    arr.push(end)
    return arr
}

module.exports = numberRange;
