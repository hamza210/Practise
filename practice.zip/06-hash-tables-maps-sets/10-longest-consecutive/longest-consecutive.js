function longestConsecutiveSequence(arr) {
    const nums = new Set(arr)

    let longestConsecutive = 0

    for(const num of nums){
        if(!nums.has(num-1)){
            let currentnum = num;
            let curentcons = 1;

            while(nums.has(currentnum+1)){
                currentnum++;
                curentcons++;
            }
            longestConsecutive = Math.max(longestConsecutive,curentcons)
        }
    }

    return longestConsecutive
}

module.exports = longestConsecutiveSequence;
