function anagramGrouping(arr) {
    const anagram = new Map()

    for (let i = 0; i < arr.length; i++) {
        let word = arr[i].split('').sort().join('')
        if (anagram.has(word)) {
            anagram.get(word).push(arr[i])
        } else {
            anagram.set(word,[arr[i]])
        }
    }

    return anagram.values()
}

module.exports = anagramGrouping;
