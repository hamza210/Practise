function wordFrequencyCounter(str) {
    const word = new Map()
    let words = str.toLowerCase().split(' ')
    for(let i=0;i<words.length;i++){
        if(word.has(words[i])){
            word.set(words[i],word.get(words[i]) + 1)
        }else{
            word.set(words[i],1)
        }
    }
    return word
}

module.exports = wordFrequencyCounter;
