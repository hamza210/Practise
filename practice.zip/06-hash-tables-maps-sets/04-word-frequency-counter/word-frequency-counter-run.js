const wordFrequencyCounter = require('./word-frequency-counter');

const result = wordFrequencyCounter(
  'The quick brown fox jumps over the lazy dog.'
);

console.log(result);
