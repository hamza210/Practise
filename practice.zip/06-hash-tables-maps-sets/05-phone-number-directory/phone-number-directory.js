function phoneNumberDirectory(arr) {
    const directory = new Map()

    for (let i = 0; i < arr.length; i++) {
        directory.set(arr[i].split(':')[0],arr[i].split(':')[1])
    }

    return directory
}

module.exports = phoneNumberDirectory;
