const twoSum = require('./two-sum');

const result = twoSum([2, 7, 11, 15], 17);

console.log(result);
