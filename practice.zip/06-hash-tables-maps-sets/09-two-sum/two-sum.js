function twoSum(arr,tar) {
    const sums = new Set()

    for (let i = 0; i < arr.length; i++) {
        let diff = tar - arr[i]
        if(sums.has(diff)){
            return([arr.indexOf(diff),i])
        }
        
        sums.add(arr[i])
    }

    return []
}

module.exports = twoSum;
