function arrayIntersection(a,b) {
    let arr = []
    for(let i=0;i<a.length;i++){
        for(j=0;j<b.length;j++){
            if(a[i] === b[j] && !arr.includes(a[i])){
                arr.push(a[i])
            }
        }
    }
    return arr
}

module.exports = arrayIntersection;
