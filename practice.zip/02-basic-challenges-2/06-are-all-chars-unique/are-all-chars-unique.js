function areAllCharactersUnique() {}

module.exports = areAllCharactersUnique;
