const findMissingLetter = require('./find-missing-letter');

result = findMissingLetter(['a', 'b', 'c', 'f', 'g']);

console.log(result);
