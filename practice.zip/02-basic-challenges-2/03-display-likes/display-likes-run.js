const displayLikes = require('./display-likes');

const result = displayLikes(['Alex', 'Jacob', 'Mark', 'Max', 'Jill']);

console.log(result);
