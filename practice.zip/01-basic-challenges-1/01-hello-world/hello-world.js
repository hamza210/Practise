function helloWorld() {
    return 'Hello World!'
}

module.exports = helloWorld;
