function countOccurrences(str,alp) {
    let val = 0
    for(let i=0;i<str.length;i++){
        if(str[i] === alp){
            val++
        }
    }
    return val
}

module.exports = countOccurrences;
