function isPalindrome(str) {
    if(str.length ===0){
        return false
    }
    let s = str.trim().toLowerCase()
    for (let i = 0; i < s.length/2; i++) {
        if(s[i] !== s[s.length - 1 - i]){
            return false
        }else {
            return true
        }        
    }
}

module.exports = isPalindrome;
