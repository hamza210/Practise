function countVowels(str) {
    let vowel = ['a','e','i','o','u']
    let val =0
    for (let i = 0; i < str.length; i++) {
        if(vowel.includes(str[i].toLowerCase())){
            val++
        }
    }
    return val
}

module.exports = countVowels;
