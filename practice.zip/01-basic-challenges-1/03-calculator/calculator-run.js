const calculator = require('./calculator');

const result = calculator(1, 2, '+');

console.log(result);
