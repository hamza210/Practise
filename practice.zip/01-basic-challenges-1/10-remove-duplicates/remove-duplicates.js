function removeDuplicates(arr) {
    // return [... new Set(arr)]
    let newarr = []
    for (let i = 0; i < arr.length; i++) {
        if(!newarr.includes(arr[i])) {
            newarr.push(arr[i])
        }
    }
    return newarr
}

module.exports = removeDuplicates;
