function maxSubarraySum(arr,k) {
    let current  = 0
    let max = 0
    for(let i=0;i<k;i++){
        max+=arr[i]
    }

    current = max

    for(let i =k;i<arr.length;i++){
        current = current - arr[i-k] + arr[i]
        current > max ? max = current : ''
    }

    return max
}

module.exports = maxSubarraySum;
