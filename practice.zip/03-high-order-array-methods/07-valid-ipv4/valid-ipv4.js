const isValidIPv4 = () => {};

module.exports = isValidIPv4;
