const validAnagrams = require('./valid-anagrams');

const result = validAnagrams('app', 'ppa');

console.log(result);
